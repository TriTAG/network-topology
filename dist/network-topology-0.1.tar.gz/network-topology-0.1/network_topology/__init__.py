from .topo import getNetworkTopology
